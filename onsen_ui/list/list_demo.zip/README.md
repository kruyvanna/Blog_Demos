Welcome to Onsen UI

Here is how to run the project

1 Install nodejs

	http://nodejs.org/download/
	
2 Run the project

type: 
	
		node scripts/web-server.js

3 Open the url

		http://localhost:8000/app/index.html